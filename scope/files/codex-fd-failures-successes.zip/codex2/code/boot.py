import csv,random,statistics as st,sys
rows=[r for r in csv.DictReader(open('vol_paper.csv')) if r['done']=='1' and not r['err'] and r['strat'] in ('FDH','FDX','FD','FD35','FD120','FDL','FDB','A1')]
seen={}
for r in sorted(rows,key=lambda r:int(r['entry_ts'])): seen.setdefault(r['mint'],r)
pool=list(seen.values()); f=float
def paired(sel,a,b,label):
    d=[f(r[a])-f(r[b]) for r in sel]; n=len(d); random.seed(1)
    bs=[sum(random.choices(d,k=n))/n for _ in range(4000)]; bs.sort()
    print(f"{label}: n={n} mean diff {sum(d)/n*100:+.1f} pts, 90% CI [{bs[200]*100:+.1f}, {bs[3799]*100:+.1f}], P(diff<=0)={sum(x<=0 for x in bs)/4000:.3f}")
paired(pool,'r_trail25','r_trail40','pooled trail25 - trail40')
cv=[r for r in pool if r['curve']=='1']; gr=[r for r in pool if r['curve']!='1']
paired(cv,'r_trail25','r_trail40','curve trail25 - trail40')
paired(gr,'r_trail25','r_trail40','grad trail25 - trail40')
paired(cv,'r_tw','r_trail25','curve tight>wide - trail25')
paired(gr,'r_trail25','r_tw','grad trail25 - tight>wide')
paired(pool,'r_trail25','r_tw','pooled trail25 - tight>wide')
# when did trail25 fire relative to trail40? use m_trail40 (minute of trail40 sale) and compare stop prices on fast rugs: x5
fast=[r for r in pool if f(r['x5'])<0.5]
print('fast rugs (price <0.5x at 5 min): n=%d, trail25 avg x %.3f, trail40 avg x %.3f'%(len(fast),st.mean(f(r['x_trail25']) for r in fast),st.mean(f(r['x_trail40']) for r in fast)))
# how many trail25 exits are at exactly the stop level after little movement (stopped below 1.0x) vs trailed from a high
import collections
c=collections.Counter()
for r in pool:
    x25=f(r['x_trail25']); pk=f(r['peak120'])
    c['stopped under entry' if x25<0.76 else 'trailed from a high' if x25<pk*0.76 else 'held to 2h/close']+=1
print(c)
