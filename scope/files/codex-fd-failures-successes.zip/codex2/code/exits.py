import csv, statistics as st, collections, sys
rows=[r for r in csv.DictReader(open(sys.argv[1])) if r['done']=='1' and not r['err']]
BOOKS=['FDH','FDX','FD','FD35','FD120','FDL','FDB','A1']
EX=[('2x/-50','r_tp2sl50'),('1.5x/-30','r_tp15sl30'),('half2+trail','r_half2'),('trail25','r_trail25'),('trail40','r_trail40'),('trail60','r_trail60'),('tight>wide','r_tw'),('out10','r_out10'),('out15','r_out15'),('out20','r_out20')]
def f(x):
    try: return float(x)
    except: return None
def stats(vals):
    n=len(vals); 
    if n==0: return None
    avg=sum(vals)/n; won=sum(v>0 for v in vals)/n; nb=(sum(vals)-max(vals))/(n-1) if n>1 else 0
    k=max(1,n//3); thirds=[sum(vals[i*k:(i+1)*k if i<2 else n])/len(vals[i*k:(i+1)*k if i<2 else n]) for i in range(3)]
    return avg,won,nb,thirds,st.median(vals)
def table(sel, label):
    sel=sorted(sel,key=lambda r:int(r['entry_ts']))
    print(f"\n== {label}: n={len(sel)}")
    print(f"{'exit':12}{'avg':>7}{'won':>6}{'nobest':>8}{'median':>8}  thirds")
    for name,col in EX:
        vals=[f(r[col]) for r in sel if f(r[col]) is not None]
        s=stats(vals)
        if not s: continue
        avg,won,nb,th,med=s
        print(f"{name:12}{avg*100:+6.0f}%{won*100:5.0f}%{nb*100:+7.0f}%{med*100:+7.0f}%  {'/'.join(f'{t*100:+.0f}' for t in th)}")
for b in BOOKS: table([r for r in rows if r['strat']==b], b)
# pooled distinct coins across FD family (first entry per mint)
fam=[r for r in rows if r['strat'] in BOOKS]
seen={}; 
for r in sorted(fam,key=lambda r:int(r['entry_ts'])):
    seen.setdefault(r['mint'],r)
pool=list(seen.values()); table(pool,'POOLED distinct coins, FD family')
table([r for r in pool if r['curve']=='1'],'pooled curve'); table([r for r in pool if r['curve']!='1'],'pooled graduated')
# where does trail25 beat trail40 and where does it lose
d=[(f(r['r_trail25'])-f(r['r_trail40']),f(r['peak120']),r['symbol']) for r in pool]
big=[x for x in d if x[1]>=3]; print('\npooled: trail25-trail40 per trade: mean %+.3f, median %+.3f; trail25 better in %d of %d'%(sum(x[0] for x in d)/len(d),st.median(x[0] for x in d),sum(x[0]>0 for x in d),len(d)))
print('coins that peaked >=3x (n=%d): trail25-trail40 mean %+.3f; trail25 better in %d'%(len(big),sum(x[0] for x in big)/len(big),sum(x[0]>0 for x in big)))
print('coins that peaked <1.5x (n=%d): mean %+.3f'%(len([x for x in d if x[1]<1.5]),sum(x[0] for x in d if x[1]<1.5)/max(1,len([x for x in d if x[1]<1.5]))))
# distribution of trail25 exits
x25=[f(r['x_trail25']) for r in pool]; x40=[f(r['x_trail40']) for r in pool]
import math
print('x_trail25 buckets:', collections.Counter(('<0.8' if x<0.8 else '0.8-1.2' if x<1.2 else '1.2-2' if x<2 else '2-4' if x<4 else '4+') for x in x25))
print('x_trail40 buckets:', collections.Counter(('<0.8' if x<0.8 else '0.8-1.2' if x<1.2 else '1.2-2' if x<2 else '2-4' if x<4 else '4+') for x in x40))
