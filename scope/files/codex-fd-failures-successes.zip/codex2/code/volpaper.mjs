// launcher 0.4.0 (owner, 31 Oct 2026 18:41 UK: "paper trade any coin with a 5-minute volume of 300k, and one with 500k … under 1 million … the age can be anything"):
// two PAPER strategies on every Solana coin GMGN lists. Every 30 s it reads GMGN's top 100 coins by 5-minute volume; the first time a coin's
// 5-min volume is ≥ $300K (V300) or ≥ $500K (V500) and under $1M, it records a paper buy at GMGN's price. Nothing is bought or sold.
// 2 h 5 min after entry it scores the trade from GMGN's 1-minute candles: price at 5/15/30/60/120 min, peak, and the exits we tested before
// (2x or −50%, 1.5x or −30%, 40% trail from the peak), after the real-cost models in LESSONS.md (bonding curve vs PumpSwap).
// Market cap, age, holders and the GMGN row are kept with each entry so other cuts (e.g. market cap under $1M) can be read later.
import { gget, N } from "./gmgn.mjs";
import { sellQuote, qStat } from "./quote.mjs"; // 0.8.15

const n = (k, d) => (process.env[k] != null && process.env[k] !== "" && Number.isFinite(Number(process.env[k])) ? Number(process.env[k]) : d);
export const TIERS = [{ k: "V300", min: n("LAUNCH_V300", 300000) }, { k: "V500", min: n("LAUNCH_V500", 500000) }];
const MAX_VOL = n("LAUNCH_VOL_MAX", 1000000), SCORE_AFTER = 125 * 60;
export const volStat = { polls: 0, rows: 0, entries: 0, scored: 0, errors: 0, lastErr: "", lastPoll: null, maxVolSeen: null };
const now = () => Math.floor(Date.now() / 1000);
// LESSONS.md cost models: bonding curve x×0.97−0.02−1−0.02 (stops −0.01 more); PumpSwap x/1.02×0.967−1−0.006−0.02 (stops x≤0.62 −0.05 more)
const realX = (x, curve) => (x == null ? null : curve ? x * 0.97 - 0.02 - 1 - 0.02 - (x <= 0.62 ? 0.01 : 0) : x / 1.02 * 0.967 - 1 - 0.006 - 0.02 - (x <= 0.62 ? 0.05 : 0));

export function initVol(db) {
  db.exec(`CREATE TABLE IF NOT EXISTS vol_paper (id INTEGER PRIMARY KEY AUTOINCREMENT, strat TEXT, mint TEXT, name TEXT, symbol TEXT, entry_ts INTEGER, entry_price REAL, entry_mc REAL, vol5 REAL,
    created_ts INTEGER, age_min REAL, holders INTEGER, exchange TEXT, launchpad TEXT, curve INTEGER, row TEXT, done INTEGER DEFAULT 0, err TEXT,
    x5 REAL, x15 REAL, x30 REAL, x60 REAL, x120 REAL, peak120 REAL, peak_min REAL, low_before_peak REAL, x_tp2sl50 REAL, x_tp15sl30 REAL, x_trail40 REAL,
    r_tp2sl50 REAL, r_tp15sl30 REAL, r_trail40 REAL, r_hold60 REAL, r_hold120 REAL, UNIQUE (strat, mint))`);
  db.exec("CREATE TABLE IF NOT EXISTS vol_bf_done (mint TEXT PRIMARY KEY)"); // 0.7.4
  try { db.exec("ALTER TABLE vol_paper ADD COLUMN x_half2 REAL"); } catch {} try { db.exec("ALTER TABLE vol_paper ADD COLUMN r_half2 REAL"); } catch {} // 0.5.0
  for (const c of ["mk_ts INTEGER", "mk_x REAL", "mk_hi REAL", "mk_last INTEGER", "mk_sold_x REAL", "mk_sold_ts INTEGER", "mk_r REAL"]) try { db.exec(`ALTER TABLE vol_paper ADD COLUMN ${c}`); } catch {} // 0.8.10 live mark
  // 0.8.16 (owner, 5 Nov 04:22 UK, after the best-exit study in LAUNCHER.md): the VENUE exit — a 25% trail on graduated coins, the 40% trail on curve coins —
  // scored on every trade (x_venue / r_venue / m_venue), followed by the live mark (mk_pct = the trail it used) and by the shadow sells; plus the open-position
  // quote poll (q_live_*: the latest sell quote, its high since entry and how many quotes) whose own trail fires the quoted exit (q_exit_src = 'poll'; 'mark' = quoted when the candle mark sold).
  for (const c of ["x_venue REAL", "r_venue REAL", "m_venue REAL", "mk_pct REAL", "q_live_ts INTEGER", "q_live_x REAL", "q_live_hi REAL", "q_live_n INTEGER", "q_exit_src TEXT"]) try { db.exec(`ALTER TABLE vol_paper ADD COLUMN ${c}`); } catch {}
  try { db.prepare("UPDATE vol_paper SET x_venue=CASE WHEN curve=1 THEN x_trail40 ELSE x_trail25 END, r_venue=CASE WHEN curve=1 THEN r_trail40 ELSE r_trail25 END, m_venue=CASE WHEN curve=1 THEN m_trail40 ELSE NULL END WHERE done=1 AND err IS NULL AND x_venue IS NULL AND x_trail25 IS NOT NULL").run(); } catch {} // scored trades: the venue exit is one of two columns they already have (no candle calls)
  try { db.prepare("UPDATE vol_paper SET q_exit_src='mark' WHERE q_exit_x IS NOT NULL AND q_exit_src IS NULL").run(); } catch {}
}
/** the venue exit's trail: 40% off the high on the curve, 25% once graduated (LAUNCHER.md 5 Nov 04:15 UK: curve runners wobble, graduated moves fade) */
export const trailPct = (curve) => (curve === 1 ? 0.4 : 0.25);

/** 0.8.10 (owner, 4 Nov 22:59 UK: "show each open trade's result within minutes… go do that"): the LIVE MARK. Every 15 s (0.8.16; was every minute), for every open trade whose venue trail (0.8.16; was the 40% trail) has not
 *  sold yet (one GMGN candle call per coin, shared by the books that hold it): price now vs entry (mk_x), the high since entry (mk_hi) and, the minute the
 *  trail would have sold, the sale (mk_sold_x, mk_sold_ts, mk_r after costs). Same replay as volScore's trail (candles after the entry minute, stop = 60% of
 *  the high), so the live number and the 2-hour score agree; the 2-hour score stays the record. A sold trade is not fetched again. */
export const markStat = { passes: 0, marked: 0, sold: 0, calls: 0, errors: 0, lastErr: "", lastPass: null };
let marking = false;
export async function volMark(db) {
  if (marking) return; marking = true;
  try {
    const t = now();
    const rows = db.prepare("SELECT id, mint, entry_ts, entry_price, curve, mk_hi, mk_last, q_tokens, q_exit_ts, strat FROM vol_paper WHERE done=0 AND err IS NULL AND mk_sold_ts IS NULL AND entry_ts>=? AND entry_ts<=? ORDER BY entry_ts LIMIT 80").all(t - 125 * 60, t - 60);
    const byMint = new Map(); for (const r of rows) { if (!byMint.has(r.mint)) byMint.set(r.mint, []); byMint.get(r.mint).push(r); }
    markStat.passes++;
    for (const [mint, rs] of byMint) {
      try {
        const from = Math.max(Math.min(...rs.map((r) => r.mk_last || r.entry_ts)) - 60, t - 98 * 60); // ≤ 100 candles a call; the high so far is carried in mk_hi
        const ks = (await candles(mint, from, t)).sort((a, b) => a.t - b.t); markStat.calls++;
        if (!ks.length) continue;
        for (const r of rs) {
          const X = (v) => v / r.entry_price, keep = 1 - trailPct(r.curve); let hi = r.mk_hi || 1, last = r.mk_last || r.entry_ts, sold = null, soldT = null; // 0.8.16: the venue trail
          for (const c of ks) { if (c.t <= last) continue; if (c.t <= r.entry_ts) { last = c.t; continue; } // the entry minute's candle is skipped, as in volScore
            if (X(c.l) <= hi * keep) { sold = hi * keep; soldT = c.t; last = c.t; break; } hi = Math.max(hi, X(c.h)); if (c.t + 60 <= t) last = c.t; } // the current minute's candle is still forming: re-read it next pass
          const nowX = X(ks[ks.length - 1].c);
          if (sold != null) { db.prepare("UPDATE vol_paper SET mk_ts=?, mk_x=?, mk_hi=?, mk_last=?, mk_sold_x=?, mk_sold_ts=?, mk_r=?, mk_pct=? WHERE id=?").run(t, +nowX.toFixed(4), +hi.toFixed(4), last, +sold.toFixed(4), soldT, realX(sold, r.curve === 1), 1 - keep, r.id); markStat.sold++;
            if (r.q_tokens > 0 && r.q_exit_ts == null) shadowSell(db, r, sold, soldT, "mark").catch(() => {}); // 0.8.15: the real sell quote the moment the candle mark says the trail sold (0.8.16: the mark runs every 15 s; skipped when the quote poll already sold)
            else db.prepare("UPDATE vol_paper SET q_exit_gap=q_exit_x/?-1 WHERE id=? AND q_exit_src='poll' AND q_exit_gap IS NULL AND q_exit_x IS NOT NULL").run(sold, r.id); } // the poll's exit against the paper sale it now has
          else db.prepare("UPDATE vol_paper SET mk_ts=?, mk_x=?, mk_hi=?, mk_last=?, mk_pct=? WHERE id=?").run(t, +nowX.toFixed(4), +hi.toFixed(4), last, 1 - keep, r.id);
          markStat.marked++;
        }
      } catch (e) { markStat.errors++; markStat.lastErr = `${mint.slice(0, 6)} ${e.message}`.slice(0, 160); if (/rate limited/i.test(e.message)) break; }
    }
    markStat.lastPass = new Date().toISOString();
  } catch (e) { markStat.errors++; markStat.lastErr = "mark: " + e.message.slice(0, 160); }
  finally { marking = false; }
}

export async function volPoll(db) {
  try {
    const d = await gget("/v1/market/rank", { chain: "sol", interval: "5m", order_by: "volume", limit: "100" });
    const rows = Array.isArray(d?.rank) ? d.rank : Array.isArray(d) ? d : []; volStat.polls++; volStat.rows = rows.length; volStat.lastPoll = new Date().toISOString();
    const t = now(), ins = db.prepare(`INSERT OR IGNORE INTO vol_paper (strat, mint, name, symbol, entry_ts, entry_price, entry_mc, vol5, created_ts, age_min, holders, exchange, launchpad, curve, row)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
    for (const r of rows) {
      const mint = r.address, v5 = N(r.volume), mc = N(r.market_cap), px = N(r.price), created = N(r.creation_timestamp ?? r.open_timestamp);
      if (v5 != null) volStat.maxVolSeen = Math.max(volStat.maxVolSeen || 0, v5);
      if (!mint || !(px > 0) || v5 == null || v5 >= MAX_VOL) continue;
      const ex = r.exchange ?? null, curve = ex ? (/^pump(fun|_fun)?$|bonding|curve/i.test(ex) ? 1 : 0) : null;
      // 0.7.2 (owner, 3 Nov 11:23 UK): VA — older coins (12 h to 14 days), 5-min volume ≥ $100K / $200K / $300K, market cap under $2M (the $1M cut is a column);
      // one strategy key per level × age bucket (VA100_12h, VA200_24h, …). Paper only; "the market when the bundles are out and new alpha may come in".
      if (created && mc != null && mc < 2e6) { const ageH = (t - created) / 3600; const bucket = ageH >= 12 && ageH < 24 ? "12h" : ageH >= 24 && ageH < 36 ? "24h" : ageH >= 36 && ageH < 48 ? "36h" : ageH >= 48 && ageH <= 14 * 24 ? "48h" : null;
        if (bucket) for (const lvl of [100000, 200000, 300000]) if (v5 >= lvl) { const ch = ins.run(`VA${lvl / 1000}_${bucket}`, mint, r.name ?? null, r.symbol ?? null, t, px, mc, v5, created, +((t - created) / 60).toFixed(1), N(r.holder_count), ex, r.launchpad_platform ?? r.launchpad ?? null, curve, JSON.stringify(r).slice(0, 1500)).changes; if (ch) volStat.entries++; } }
      for (const tier of TIERS) if (v5 >= tier.min) {
        const ch = ins.run(tier.k, mint, r.name ?? null, r.symbol ?? null, t, px, mc, v5, created, created ? +((t - created) / 60).toFixed(1) : null, N(r.holder_count), ex, r.launchpad_platform ?? r.launchpad ?? null, curve, JSON.stringify(r).slice(0, 1500)).changes;
        if (ch) volStat.entries++;
      }
    }
  } catch (e) { volStat.errors++; volStat.lastErr = "poll: " + e.message.slice(0, 160); }
}

async function candles(mint, from, to) {
  const d = await gget("/v1/market/token_kline", { chain: "sol", address: mint, resolution: "1m", from: String(from * 1000), to: String(to * 1000) });
  return (d?.list || (Array.isArray(d) ? d : [])).map((c) => ({ t: Math.floor(Number(c.time) / 1000), h: N(c.high), l: N(c.low), c: N(c.close) })).filter((c) => c.h > 0);
}
let scoring = false;
/** 0.8.8 (owner, 4 Nov 18:53 UK: "a time for each position at what time it was actually live"): fill the 40%-trail exit minute on trades scored before this column existed, without blanking them. */
let filling = false;
export async function volFillExitTime(db) {
  if (filling) return; filling = true;
  try {
    for (const p of db.prepare("SELECT id, mint, entry_ts, entry_price FROM vol_paper WHERE done=1 AND err IS NULL AND m_trail40 IS NULL AND x_trail40 IS NOT NULL AND entry_ts>=? ORDER BY entry_ts DESC LIMIT 15").all(now() - 3 * 86400)) {
      try {
        const e = p.entry_ts, path = [...await candles(p.mint, e - 60, e + 60 * 60), ...await candles(p.mint, e + 60 * 60, e + 121 * 60)].filter((c) => c.t >= e - 60).sort((a, b) => a.t - b.t).filter((c, i, a) => i === 0 || c.t !== a[i - 1].t);
        const after = path.filter((c) => c.t >= e - 60), X = (v) => v / p.entry_price; let hi = 1, t = null;
        for (const c of after.slice(1)) { if (X(c.l) <= hi * 0.6) { t = c.t; break; } hi = Math.max(hi, X(c.h)); }
        db.prepare("UPDATE vol_paper SET m_trail40=? WHERE id=?").run(t ? +((t - e) / 60).toFixed(1) : -1, p.id); // −1 = still held at 2 h
      } catch (er) { if (/rate limited/i.test(er.message)) break; db.prepare("UPDATE vol_paper SET m_trail40=-2 WHERE id=?").run(p.id); }
    }
  } catch {} finally { filling = false; }
}
export async function volScore(db) {
  if (scoring) return; scoring = true;
  try {
    for (const p of db.prepare("SELECT * FROM vol_paper WHERE done=0 AND entry_ts<=? ORDER BY entry_ts LIMIT 40").all(now() - SCORE_AFTER)) {
      try {
        const e = p.entry_ts, path = [...await candles(p.mint, e - 60, e + 60 * 60), ...await candles(p.mint, e + 60 * 60, e + 121 * 60)].filter((c) => c.t >= e - 60).sort((a, b) => a.t - b.t);
        const uniq = path.filter((c, i) => i === 0 || c.t !== path[i - 1].t);
        if (!uniq.length) { db.prepare("UPDATE vol_paper SET done=1, err=? WHERE id=?").run("no candles", p.id); continue; }
        const X = (v) => v / p.entry_price, at = (m) => { const c = uniq.filter((x) => x.t <= e + m * 60).pop(); return c ? +X(c.c).toFixed(4) : null; };
        const after = uniq.filter((c) => c.t >= e - 60);
        let peak = 0, peakT = e; for (const c of after) if (X(c.h) > peak) { peak = X(c.h); peakT = c.t; }
        const lowBefore = Math.min(...after.filter((c) => c.t <= peakT).map((c) => X(c.l)));
        const tpsl = (tp, sl) => { for (const c of after.slice(1)) { if (X(c.l) <= sl) return sl; if (X(c.h) >= tp) return tp; } return X(after[after.length - 1].c); }; // the stop is checked first in a candle: the worse case
        let hi = 1, trail = null, trailT = null; for (const c of after.slice(1)) { if (X(c.l) <= hi * 0.6) { trail = hi * 0.6; trailT = c.t; break; } hi = Math.max(hi, X(c.h)); } if (trail == null) trail = X(after[after.length - 1].c); // 0.8.8: trailT = when the 40% trail sold (null = still held at 2 h)
        // 0.5.0: half at 2x, the rest on a 40% trail from the peak; −30% stop before 2x
        let half = null; { let hit = false, hi2 = 2; for (const c of after.slice(1)) { if (!hit) { if (X(c.l) <= 0.7) { half = 0.7; break; } if (X(c.h) >= 2) { hit = true; hi2 = Math.max(2, X(c.h)); } } else { if (X(c.l) <= hi2 * 0.6) { half = 1 + 0.5 * hi2 * 0.6; break; } hi2 = Math.max(hi2, X(c.h)); } }
          if (half == null) half = hit ? 1 + 0.5 * X(after[after.length - 1].c) : X(after[after.length - 1].c); }
        const cv = p.curve === 1, t2 = tpsl(2, 0.5), t15 = tpsl(1.5, 0.7), h60 = at(60), h120 = at(120);
        // 0.8.0: hard out at minute M (winners peak at ~16 min and are worthless by 30), −35% stop before it; the stop is checked first in a candle
        const out = (M) => { for (const c of after.slice(1)) { if (c.t > e + M * 60) break; if (X(c.l) <= 0.65) return 0.65; } const c = uniq.filter((x) => x.t <= e + M * 60).pop(); return c ? +X(c.c).toFixed(4) : null; };
        const o10 = out(10), o15 = out(15), o20 = out(20);
        // 0.8.7 (owner, 4 Nov 18:21 UK: "more potential exit points… find the maximum"): trails of 25% and 60%, and tight-then-wide — a −35% stop until the coin has doubled, then a 55% trail off the high
        const trailN = (pct) => { let h = 1; for (const c of after.slice(1)) { if (X(c.l) <= h * (1 - pct)) return h * (1 - pct); h = Math.max(h, X(c.h)); } return X(after[after.length - 1].c); };
        const tw = (() => { let h = 1, run = false; for (const c of after.slice(1)) { if (!run) { if (X(c.l) <= 0.65) return 0.65; if (X(c.h) >= 2) { run = true; h = X(c.h); } } else { if (X(c.l) <= h * 0.45) return h * 0.45; h = Math.max(h, X(c.h)); } } return X(after[after.length - 1].c); })();
        const t25 = trailN(0.25), t60 = trailN(0.6);
        // 0.8.16: the venue exit — the 40% trail on the curve, the 25% trail once graduated — with its sale minute (m_venue; −1 = still held at 2 h)
        const vn = (() => { if (cv) return { x: trail, t: trailT }; let h = 1; for (const c of after.slice(1)) { if (X(c.l) <= h * 0.75) return { x: h * 0.75, t: c.t }; h = Math.max(h, X(c.h)); } return { x: X(after[after.length - 1].c), t: null }; })();
        db.prepare(`UPDATE vol_paper SET done=1, x5=?, x15=?, x30=?, x60=?, x120=?, peak120=?, peak_min=?, low_before_peak=?, x_tp2sl50=?, x_tp15sl30=?, x_trail40=?, r_tp2sl50=?, r_tp15sl30=?, r_trail40=?, r_hold60=?, r_hold120=?, x_half2=?, r_half2=?, x_out10=?, x_out15=?, x_out20=?, r_out10=?, r_out15=?, r_out20=?, x_trail25=?, x_trail60=?, x_tw=?, r_trail25=?, r_trail60=?, r_tw=?, m_trail40=?, x_venue=?, r_venue=?, m_venue=? WHERE id=?`)
          .run(at(5), at(15), at(30), h60, h120, +peak.toFixed(4), +((peakT - e) / 60).toFixed(1), +lowBefore.toFixed(4), t2, t15, +trail.toFixed(4), realX(t2, cv), realX(t15, cv), realX(trail, cv), realX(h60, cv), realX(h120, cv), +half.toFixed(4), realX(half, cv), o10, o15, o20, realX(o10, cv), realX(o15, cv), realX(o20, cv), +t25.toFixed(4), +t60.toFixed(4), +tw.toFixed(4), realX(t25, cv), realX(t60, cv), realX(tw, cv), trailT ? +((trailT - e) / 60).toFixed(1) : -1, +vn.x.toFixed(4), realX(vn.x, cv), vn.t ? +((vn.t - e) / 60).toFixed(1) : -1, p.id);
        try { db.prepare("UPDATE vol_paper SET q_exit_gap=q_exit_x/x_venue-1 WHERE id=? AND q_exit_x IS NOT NULL AND q_exit_gap IS NULL AND x_venue>0").run(p.id); } catch {} // 0.8.16: a poll exit on a trade the mark never sold, against the scored venue exit
        volStat.scored++;
      } catch (er) { if (/rate limited/i.test(er.message)) throw er; db.prepare("UPDATE vol_paper SET done=1, err=? WHERE id=?").run(er.message.slice(0, 120), p.id); }
    }
  } catch (e) { volStat.errors++; volStat.lastErr = "score: " + e.message.slice(0, 160); }
  finally { scoring = false; }
}

// 0.7.2: the VA backfill — a back-test, kept apart from the live book ("BF-VA…"). Every tracker coin that peaked ≥ $50K: 5-minute candles over the last
// 14 days (GMGN), the first crossing of $100K / $200K / $300K 5-min volume while 12 h–14 d old and under $2M market cap becomes a paper entry at that
// candle's close; scored by the same volScore from the same candles. ~1,000 coins × 3 pages. Runs once, 40 coins a tick, in the background.
export const bfStat = { coins: 0, done: 0, entries: 0, errors: 0, lastErr: "", finished: false };
let bfList = null;
export async function volBackfill(db, tdb) {
  if (!tdb || bfStat.finished) return;
  try {
    if (!bfList) { const since = now() - 15 * 86400; bfList = tdb.prepare("SELECT mint, name, symbol, create_ts, peak_mc_usd FROM tokens WHERE peak_mc_usd>=50000 AND create_ts>=? ORDER BY peak_mc_usd DESC LIMIT 1500").all(since); bfStat.coins = bfList.length;
      const seen = new Set(db.prepare("SELECT mint FROM vol_bf_done").all().map((r) => r.mint)); bfList = bfList.filter((c) => !seen.has(c.mint)); bfStat.done = seen.size; } // 0.7.4: coins scanned before a restart are not scanned again
    const ins = db.prepare(`INSERT OR IGNORE INTO vol_paper (strat, mint, name, symbol, entry_ts, entry_price, entry_mc, vol5, created_ts, age_min, holders, exchange, launchpad, curve, row) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
    let k = 0;
    while (bfList.length && k < n("LAUNCH_BF_PER_TICK", 8)) { // 0.7.7: was 40 a tick (~1,700 GMGN calls every 2 min) — it was starving the study
      const c = bfList.shift(); k++;
      try {
        const from = Math.max(c.create_ts + 12 * 3600, now() - 14 * 86400), to = Math.min(now() - 125 * 60, c.create_ts + 14 * 86400); if (to <= from) { bfStat.done++; continue; }
        const all = [];
        for (let a = from; a < to; a += 100 * 300) { const d = await gget("/v1/market/token_kline", { chain: "sol", address: c.mint, resolution: "5m", from: String(a * 1000), to: String(Math.min(to, a + 100 * 300) * 1000) }); all.push(...(d?.list || (Array.isArray(d) ? d : []))); }
        const rows = all.map((x) => ({ t: Math.floor(Number(x.time) / 1000), c: N(x.close), v: N(x.volume) })).filter((x) => x.c > 0 && x.v != null).sort((a, b) => a.t - b.t);
        const hit = {};
        for (const x of rows) { const ageH = (x.t - c.create_ts) / 3600, mc = x.c * 1e9; if (ageH < 12 || ageH > 14 * 24 || !(mc < 2e6)) continue;
          const bucket = ageH < 24 ? "12h" : ageH < 36 ? "24h" : ageH < 48 ? "36h" : "48h";
          for (const lvl of [100000, 200000, 300000]) { const key = `BF-VA${lvl / 1000}_${bucket}`; if (x.v >= lvl && !hit[key]) { hit[key] = 1; if (ins.run(key, c.mint, c.name, c.symbol, x.t, x.c, mc, x.v, c.create_ts, +((x.t - c.create_ts) / 60).toFixed(1), null, "backfill", null, 0, JSON.stringify({ backfill: true, peak_mc_usd: c.peak_mc_usd })).changes) bfStat.entries++; } } }
        bfStat.done++; db.prepare("INSERT OR IGNORE INTO vol_bf_done VALUES (?)").run(c.mint);
      } catch (e) { bfStat.errors++; bfStat.lastErr = `${c.mint.slice(0, 6)} ${e.message}`.slice(0, 140); if (/rate limited/i.test(e.message)) { bfList.unshift(c); break; } bfStat.done++; }
    }
    if (!bfList.length) bfStat.finished = true;
  } catch (e) { bfStat.errors++; bfStat.lastErr = e.message.slice(0, 140); }
}

/** 0.8.15: sell quote for the tokens the buy quote said we would hold; q_exit_x = SOL back ÷ SOL staked, q_exit_gap = q_exit_x ÷ paper exit multiple − 1 */
const SHADOW_SOL = Number(process.env.LAUNCH_SHADOW_SOL || 0.2);
async function shadowSell(db, r, paperX, soldT, src = "mark") {
  try { const q = await sellQuote(r.mint, r.q_tokens); const x = q.lamports / 1e9 / SHADOW_SOL; qStat.sells++;
    db.prepare("UPDATE vol_paper SET q_exit_ts=?, q_exit_sol=?, q_exit_x=?, q_exit_gap=?, q_exit_delay=?, q_exit_impact=?, q_exit_src=? WHERE id=? AND q_exit_x IS NULL").run(now(), +(q.lamports / 1e9).toFixed(4), +x.toFixed(4), +(x / paperX - 1).toFixed(4), now() - soldT, q.impact, src, r.id);
  } catch (e) { qStat.errors++; qStat.lastErr = `sell ${r.mint.slice(0, 6)}: ${e.message}`.slice(0, 120); if (!/paused/.test(e.message)) db.prepare("UPDATE vol_paper SET q_exit_ts=?, q_exit_err=? WHERE id=? AND q_exit_x IS NULL").run(now(), e.message.slice(0, 80), r.id); }
}

/** 0.8.16 (owner, 5 Nov 04:22 UK): the OPEN-POSITION QUOTE POLL — what a live bot running the venue trail off its own sell quotes would have got.
 *  Every 3 s one Jupiter sell quote for the open shadow position that was quoted longest ago (all the books' rows of that coin share it): the quoted
 *  x (SOL back ÷ SOL staked), its high since entry (from 1 = the entry, like the paper trail) and, the first quote at or under high × (1 − trail), the
 *  quoted exit (q_exit_* with q_exit_src = 'poll', delay 0). The candle mark's quote ('mark') is only taken when the poll has not sold first.
 *  With N open coins each is quoted every 3N seconds; 30 keyless requests a minute leave room for the entry quotes. */
let polling = false;
export async function volQuotePoll(db) {
  if (polling || Date.now() < qStat.pauseUntil) return; polling = true;
  try {
    const t = now();
    const first = db.prepare("SELECT mint FROM vol_paper WHERE done=0 AND err IS NULL AND q_tokens>0 AND q_exit_ts IS NULL AND entry_ts>=? AND entry_ts<=? ORDER BY (q_live_ts IS NOT NULL), q_live_ts, entry_ts LIMIT 1").get(t - 125 * 60, t - 20);
    if (!first) return;
    const rs = db.prepare("SELECT id, mint, curve, q_tokens, q_live_hi FROM vol_paper WHERE mint=? AND done=0 AND err IS NULL AND q_tokens>0 AND q_exit_ts IS NULL").all(first.mint);
    if (!rs.length) return;
    const base = rs[0]; qStat.polls++;
    let q; try { q = await sellQuote(base.mint, base.q_tokens); }
    catch (e) { qStat.errors++; qStat.lastErr = `poll ${base.mint.slice(0, 6)}: ${e.message}`.slice(0, 120);
      if (!/paused|429/.test(e.message)) for (const r of rs) db.prepare("UPDATE vol_paper SET q_live_ts=?, q_live_n=COALESCE(q_live_n,0)+1 WHERE id=?").run(t, r.id); // a coin with no route (rugged curve) is not retried before the others
      return; }
    for (const r of rs) {
      const x = q.lamports / 1e9 / SHADOW_SOL * (r.q_tokens / base.q_tokens), hi = Math.max(r.q_live_hi || 1, x), keep = 1 - trailPct(r.curve);
      if (x <= (r.q_live_hi || 1) * keep) { // the trail off the quoted high fires on this quote: this is the quoted exit (compared with the paper exit by the page, once the mark or the score has it)
        db.prepare("UPDATE vol_paper SET q_live_ts=?, q_live_x=?, q_live_hi=?, q_live_n=COALESCE(q_live_n,0)+1, q_exit_ts=?, q_exit_sol=?, q_exit_x=?, q_exit_delay=0, q_exit_impact=?, q_exit_src='poll' WHERE id=? AND q_exit_x IS NULL")
          .run(t, +x.toFixed(4), +hi.toFixed(4), t, +(q.lamports / 1e9 * (r.q_tokens / base.q_tokens)).toFixed(4), +x.toFixed(4), q.impact, r.id); qStat.pollExits++; qStat.sells++;
      } else db.prepare("UPDATE vol_paper SET q_live_ts=?, q_live_x=?, q_live_hi=?, q_live_n=COALESCE(q_live_n,0)+1 WHERE id=?").run(t, +x.toFixed(4), +hi.toFixed(4), r.id);
    }
  } catch (e) { qStat.errors++; qStat.lastErr = "poll: " + e.message.slice(0, 120); }
  finally { polling = false; }
}
